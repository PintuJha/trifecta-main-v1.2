import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">



<nav class="navbar fixed-top">
        <div class="d-flex align-items-center navbar-left">
            <a href="#" class="menu-button d-none d-md-block">
                <svg class="main" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 17">
                    <rect x="0.48" y="0.5" width="7" height="1" />
                    <rect x="0.48" y="7.5" width="7" height="1" />
                    <rect x="0.48" y="15.5" width="7" height="1" />
                </svg>
                <svg class="sub" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 17">
                    <rect x="1.56" y="0.5" width="16" height="1" />
                    <rect x="1.56" y="7.5" width="16" height="1" />
                    <rect x="1.56" y="15.5" width="16" height="1" />
                </svg>
            </a>

            <a href="#" class="menu-button-mobile d-xs-block d-sm-block d-md-none">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 17">
                    <rect x="0.5" y="0.5" width="25" height="1" />
                    <rect x="0.5" y="7.5" width="25" height="1" />
                    <rect x="0.5" y="15.5" width="25" height="1" />
                </svg>
            </a>

            <div class="search" data-search-path="Layouts.Search.html?q=">
                <input placeholder="Search..." />
                <span class="search-icon">
                    <i class="simple-icon-magnifier"></i>
                </span>
            </div>
        </div>


        <a class="navbar-logo" href="javascript:void(0);">
            <span class="logo d-none d-xs-block"></span>
            <span class="logo-mobile d-block d-xs-none"></span>
        </a>

        <div class="navbar-right">
            <div class="header-icons d-inline-block align-middle">
                          <div class="position-relative d-none d-sm-inline-block">
                    <button class="header-icon btn btn-empty" type="button" id="iconMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        <i class="simple-icon-grid"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right mt-3  position-absolute" id="iconMenuDropdown">
                        <a href="#" class="icon-menu-item">
                            <i class="iconsmind-Equalizer d-block"></i>
                            <span>Settings</span>
                        </a>

                        <a href="#" class="icon-menu-item">
                            <i class="iconsmind-MaleFemale d-block"></i>
                            <span>Users</span>
                        </a>

                        <a href="#" class="icon-menu-item">
                            <i class="iconsmind-Puzzle d-block"></i>
                            <span>Components</span>
                        </a>

                        <a href="#" class="icon-menu-item">
                            <i class="iconsmind-Bar-Chart d-block"></i>
                            <span>Profits</span>
                        </a>

                        <a href="#" class="icon-menu-item">
                            <i class="iconsmind-File-Chart d-block"></i>
                            <span>Surveys</span>
                        </a>

                        <a href="#" class="icon-menu-item">
                            <i class="iconsmind-Suitcase d-block"></i>
                            <span>Tasks</span>
                        </a>

                    </div>
                </div>

                <div class="position-relative d-inline-block">
                    <button class="header-icon btn btn-empty" type="button" id="notificationButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        <i class="simple-icon-bell"></i>
                        <span class="count">3</span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right mt-3 scroll position-absolute" id="notificationDropdown">

                        <div class="d-flex flex-row mb-3 pb-3 border-bottom">
                            <a href="#">
                                <img src="http://hotel.trifectahms.in/image/18.jpg" alt="Notification Image" class="img-thumbnail list-thumbnail xsmall border-0 rounded-circle" />
                            </a>
                            <div class="pl-3 pr-2">
                                <a href="#">
                                    <p class="font-weight-medium mb-1">Joisse Kaycee just sent a new comment!</p>
                                    <p class="text-muted mb-0 text-small">09.04.2018 - 12:45</p>
                                </a>
                            </div>
                        </div>

                        <div class="d-flex flex-row mb-3 pb-3 border-bottom">
                            <a href="#">
                                <img src="http://hotel.trifectahms.in/image/18.jpg" alt="Notification Image" class="img-thumbnail list-thumbnail xsmall border-0 rounded-circle" />
                            </a>
                            <div class="pl-3 pr-2">
                                <a href="#">
                                    <p class="font-weight-medium mb-1">1 item is out of stock!</p>
                                    <p class="text-muted mb-0 text-small">09.04.2018 - 12:45</p>
                                </a>
                            </div>
                        </div>


                        <div class="d-flex flex-row mb-3 pb-3 border-bottom">
                            <a href="#">
                                <img src="http://hotel.trifectahms.in/image/18.jpg" alt="Notification Image" class="img-thumbnail list-thumbnail xsmall border-0 rounded-circle" />
                            </a>
                            <div class="pl-3 pr-2">
                                <a href="#">
                                    <p class="font-weight-medium mb-1">New order received! It is total $147,20.</p>
                                    <p class="text-muted mb-0 text-small">09.04.2018 - 12:45</p>
                                </a>
                            </div>
                        </div>

                        <div class="d-flex flex-row mb-3 pb-3 ">
                            <a href="#">
                                <img src="http://hotel.trifectahms.in/image/18.jpg" alt="Notification Image" class="img-thumbnail list-thumbnail xsmall border-0 rounded-circle" />
                            </a>
                            <div class="pl-3 pr-2">
                                <a href="#">
                                    <p class="font-weight-medium mb-1">3 items just added to wish list by a user!</p>
                                    <p class="text-muted mb-0 text-small">09.04.2018 - 12:45</p>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>

                <button class="header-icon btn btn-empty d-none d-sm-inline-block" type="button" id="fullScreenButton">
                    <i class="simple-icon-size-fullscreen"></i>
                    <i class="simple-icon-size-actual"></i>
                </button>

            </div>

            <div class="user d-inline-block">
                <button class="btn btn-empty p-0" type="button" data-toggle="dropdown" aria-haspopup="true"
                    aria-expanded="false">
                    <span class="name">Sarah Kortney</span>
                    <span>
                        <img alt="Profile Picture" src="http://hotel.trifectahms.in/image/18.jpg" />
                    </span>
                </button>

                <div class="dropdown-menu dropdown-menu-right mt-3">
                    <a class="dropdown-item" href="#">Account</a>
                    <a class="dropdown-item" href="#">Features</a>
                    <a class="dropdown-item" href="#">History</a>
                    <a class="dropdown-item" href="#">Support</a>
                    <a class="dropdown-item" href="#">Sign out</a>
                </div>
            </div>
        </div>
    </nav>


    <div class="sidebar">
        <div class="main-menu">
            <div class="scroll">
                <ul class="list-unstyled">
                    <li class="active">
                        <a href="#dashboard">
                            <i class="iconsmind-Shop-4"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="#people">
                            <i class="iconsmind-Digital-Drawing"></i> People
                        </a>
                    </li>
                    <li>
                        <a href="#roommanagement">
                            <i class="iconsmind-Air-Balloon"></i>  Room Management  
                        </a>
                    </li>
                    <li>
                        <a href="#reservation">
                            <i class="iconsmind-Pantone"></i> Reservation 
                        </a>
                    </li>
                    <li>
                        <a href="#frontoffice">
                            <i class="iconsmind-Space-Needle"></i> Front Office 
                        </a>
                    </li>
                    <li>
                        <a href="#accounts">
                            <i class="iconsmind-Three-ArrowFork"></i> Accounts
                        </a>
                    </li>

                    <li>
                        <a href="#configuration">
                            <i class="iconsmind-Three-ArrowFork"></i> Configuration
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="sub-menu">
            <div class="scroll">

                <ul class="list-unstyled" data-link="people">
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-credit-card"></i> User 
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-list"></i> Staff Record
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-grid"></i>  Access Report
                        </a>
                    </li>
                   
                </ul>
              
              
                <ul class="list-unstyled" data-link="roommanagement">
                 
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-check"></i> Room Category
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-calculator"></i> Floor
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-bubbles"></i> Room No.
                        </a>
                    </li>

                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-bubbles"></i> View Tariff
                        </a>
                    </li>

                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-bubbles"></i> Edit Tariff
                        </a>
                    </li>
                </ul>
              
              
                <ul class="list-unstyled" data-link="reservation">
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-bell"></i> New Reservation
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-badge"></i>  View Reservation Details  
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-control-play"></i> Cancel List 
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-layers"></i> Travel Agent/Third Party Side 
                        </a>
                    </li>

                   
                </ul>
               
               
                <ul class="list-unstyled" data-link="frontoffice">
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-docs"></i> Stay View
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-doc"></i> Check In
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-info"></i> Check Out
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-user-following"></i> Room Shifting
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-user-follow"></i> Booking Modification
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-bubbles"></i> Early Check Out 
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-bubble"></i> EOD Sale Report 
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-people"></i> Meal Report
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-check"></i> Occupancy Report
                        </a>
                    </li>
                   
                </ul>




                <ul class="list-unstyled" data-link="accounts">
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-control-pause"></i> Salary
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-arrow-left mi-subhidden"></i> Rental
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-control-start mi-hidden"></i> Commission List
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-control-start mi-hidden"></i> New Expense
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-control-start mi-hidden"></i> New Purchase
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-control-start mi-hidden"></i> Day Summary
                        </a>
                    </li>

                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-control-start mi-hidden"></i> Sale Report
                        </a>
                    </li>

                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-control-start mi-hidden"></i> P & L Statement
                        </a>
                    </li>
                </ul>

                <ul class="list-unstyled" data-link="configuration">
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-control-pause"></i> GST Info
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">
                            <i class="simple-icon-arrow-left mi-subhidden"></i>  GST
                        </a>
                    </li>
                   
                </ul>
         
         
            </div>
        </div>
    </div>


    <main>
        <div class="container-fluid">
            <div class="row  ">
                <div class="col-12">

                    <h1>Dashboard Analytics</h1>
                    <nav class="breadcrumb-container d-none d-sm-block d-lg-inline-block" aria-label="breadcrumb">
                        <ol class="breadcrumb pt-0">
                            <li class="breadcrumb-item">
                                <a href="#">Home</a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">Library</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Data</li>
                        </ol>
                    </nav>
                    <div class="separator mb-5"></div>
                </div>
            </div>

        </div>
    </main>





    </div>
  );
}

export default App;
